﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enums  {
    public enum BirbLocation
    {
        Aviary,
        Feeder,
        NestParent,
        NestParentsEgg,
        NestHatching,
        Collection
    }        
}

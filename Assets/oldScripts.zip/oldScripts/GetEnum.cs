﻿using UnityEngine;

public class GetEnum : MonoBehaviour
{
    public Enums.BirbLocation state;
}
